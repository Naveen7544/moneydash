import React, { useEffect, useState } from "react";
import NewsCard from "../components/NewsCard";

const API_URL = `https://gnews.io/api/v4/search?q=market&token=373a106832bc502d9b3aa51b469028ea&lang=en&country=in&max=18`;

export default function Markets() {
  const [marketArticles, setMarketArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    const controller = new AbortController();

    const fetchMarketArticles = async () => {
      try {
        const res = await fetch(API_URL, { signal: controller.signal });
        const data = await res.json();

        if (!isMounted) return;

        setMarketArticles(data.articles || []);
      } catch (err) {
        if (err.name !== "AbortError" && isMounted) {
          setError(err.message);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchMarketArticles();

    return () => {
      isMounted = false;
      controller.abort();
    };
  }, []);

  return (
    <main className="p-8 pt-6">
      <h2 className="text-3xl font-bold text-emerald-400 mb-6">Live Markets</h2>
      <p className="text-slate-300 mb-6">Explore live market data, charts, and stock indices.</p>

      {loading && <p className="text-slate-400">Loading...</p>}
      {error && <p className="text-red-500">{error}</p>}
      {!loading && marketArticles.length === 0 && (
        <p className="text-slate-400">No market news found at the moment.</p>
      )}

      <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-3">
        {marketArticles.map((article, idx) => (
          <NewsCard key={idx} article={article} />
        ))}
      </div>
    </main>
  );
}
