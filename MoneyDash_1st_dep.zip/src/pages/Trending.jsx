import React, { useEffect, useState } from "react";
import NewsCard from "../components/NewsCard";

const API_URL = `https://gnews.io/api/v4/top-headlines?token=373a106832bc502d9b3aa51b469028ea&lang=en&country=in&max=18`;

const STOCK_KEYWORDS = [
  "stock", "stocks", "market", "nifty", "sensex", "equity",
  "shares", "ipo", "invest", "mutual fund", "trading", "finance", "nse", "bse"
];

export default function Trending() {
  const [trendingArticles, setTrendingArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    const controller = new AbortController();

    const fetchTrendingArticles = async () => {
      try {
        const res = await fetch(API_URL, { signal: controller.signal });
        const data = await res.json();

        console.log("Fetched Articles:", data.articles);

        if (!isMounted) return;

        const filtered = (data.articles || []).filter(article => {
          const text = `${article.title} ${article.description || ""}`.toLowerCase();
          return STOCK_KEYWORDS.some(keyword => text.includes(keyword));
        });

        console.log("Filtered Stock Articles:", filtered);

        setTrendingArticles(filtered);
      } catch (err) {
        if (err.name !== "AbortError" && isMounted) {
          setError(err.message);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchTrendingArticles();

    return () => {
      isMounted = false;
      controller.abort();
    };
  }, []);

  return (
    <main className="p-8 pt-6">
      <h2 className="text-3xl font-bold mb-6 text-emerald-400">Trending</h2>
      <p className="text-slate-300 mb-6">Trending stock market topics and financial insights.</p>

      {loading && <p className="text-slate-400">Loading...</p>}
      {error && <p className="text-red-500">{error}</p>}

      {!loading && trendingArticles.length === 0 && (
        <p className="text-slate-400">No trending stock news found right now.</p>
      )}

      <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-3">
        {trendingArticles.map((article, idx) => (
          <NewsCard key={idx} article={article} />
        ))}
      </div>
    </main>
  );
}
