import React from "react";

export default function Trending() {
  return (
    <div className="p-8">
      <h2 className="text-3xl font-bold text-emerald-400 mb-6">Trending</h2>
      <p className="text-slate-300">Trending stock market topics and financial insights.</p>
    </div>
  );
}