export default function Trending() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-emerald-400 mb-6">Trending News</h1>
      <p className="text-slate-300">Trending news content goes here.</p>
    </div>
  );
}
