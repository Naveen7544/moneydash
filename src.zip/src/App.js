import logo from './logo.svg';
import './App.css';
// import PromptGenerator from "../src/pages/PromptGenerator";
import Dashboard from "../src/pages/Dashboard"

function App() {
  return (
   <Dashboard/>
  );
}

export default App;
