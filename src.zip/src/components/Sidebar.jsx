import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  TrendingUp,
  Newspaper,
  PenLine,
  Video,
  BarChart3,
  Briefcase,
} from "lucide-react";

const navItems = [
  { path: "/", label: "Dashboard", icon: <LayoutDashboard size={20} /> },
  { path: "/trending", label: "Trending", icon: <TrendingUp size={20} /> },
  { path: "/top-news", label: "Top News", icon: <Newspaper size={20} /> },
  { path: "/editors-picks", label: "Editor's Picks", icon: <PenLine size={20} /> },
  { path: "/videos", label: "Videos", icon: <Video size={20} /> },
  { path: "/markets", label: "Markets", icon: <BarChart3 size={20} /> },
  { path: "/portfolio", label: "Portfolio", icon: <Briefcase size={20} /> },
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-slate-800 shadow-lg hidden md:flex flex-col p-6 space-y-4">
      <h2 className="text-2xl font-bold text-emerald-400 mb-6">StockNews</h2>
      <nav className="flex flex-col space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-2 rounded-xl transition hover:bg-slate-700 ${
                isActive ? "bg-emerald-600 text-white" : "text-slate-300"
              }`
            }
          >
            {item.icon}
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
